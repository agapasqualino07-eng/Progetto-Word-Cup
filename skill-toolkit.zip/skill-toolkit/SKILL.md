---
name: skill-toolkit
description: Toolkit unico con 71 skill per founder e prodotto — strategia e business plan, CFO/unit economics, pricing, offerte, lancio, marketing (SEO, copywriting, CRO, email, ads, social, PR), design UI/UX e brand, slide, code review di sicurezza, TDD e humanizer per togliere il tono da AI ai testi. Usa quando l'utente chiede una di queste attività; leggi l'indice e carica solo la skill pertinente.
---

# Skill Toolkit

Raccolta di 71 skill in un'unica cartella. Funziona come **router**: non caricare tutto, ma
scegli la skill giusta dall'indice sotto, **leggi il suo `SKILL.md`** (percorso relativo a questa cartella)
e segui le sue istruzioni, aprendo i file in `references/`, `scripts/`, `data/` solo se servono.

## Come usarla

1. Capisci cosa chiede l'utente (es. "analizza i prezzi", "scrivi una landing", "rivedi la sicurezza").
2. Trova la riga più adatta nell'indice; se ne servono più d'una, combinale (es. `founder-offer` + `copywriting` + `humanizer`).
3. Leggi il `SKILL.md` indicato per intero. I file di supporto (references/, scripts/, data/, LICENSE…) di ogni skill sono raccolti in un unico `REFERENCES.md` nella stessa cartella, con una sezione per file intitolata col percorso originale: quando lo SKILL.md cita un file, leggi quella sezione (eccezione: `design/ui-ux-pro-max` ha script e dati intatti).
4. Se nessuna skill calza, rispondi normalmente senza forzarne una.
5. Alcune skill di marketing si appoggiano al contesto prodotto: se esiste, parti da `skills/marketing/product-marketing/SKILL.md`.

## Combinazioni utili

- **Lanciare un prodotto:** `founder-plan` → `founder-offer` → `founder-pricing` → `founder-launch` → `copywriting` → `humanizer`
- **Sito/landing:** `ui-ux-pro-max` + `design-system` → `copywriting` → `cro` → `seo-audit`
- **Contenuti scritti da AI da rifinire:** `copy-editing` → `humanizer`
- **Codice sicuro:** `tdd-workflow` + `security-review`

## Indice delle skill

### Founder: strategia, finanza, pricing, lancio (founder-skill)

| Skill | Quando usarla | File |
|---|---|---|
| `founder-board` | Your board of directors. Puts a business idea in front of a three-member board, each a sub-agent reading the idea through one published framework: the Offers lens (from… | `skills/founder/founder-board/SKILL.md` |
| `founder-brand` | Your brand designer. Names the business (with the trademark, domain and handle checks to run before falling in love with a name), writes the voice, a one-line promise… | `skills/founder/founder-brand/SKILL.md` |
| `founder-cfo` | Your CFO. Builds the unit economics of a business before money is spent: what one unit earns after its direct costs, the real profit margin at the planned volume, the… | `skills/founder/founder-cfo/SKILL.md` |
| `founder-competitors` | Maps every competitor and the gap they leave. Finds the direct competitors, indirect ones and the substitutes a buyer would use instead, from public sources only, and… | `skills/founder/founder-competitors/SKILL.md` |
| `founder-consumer` | The consumer panel. Spins up a swarm of buyer sub-agents (default 100, --quick for 20) trained on the user's target customer, each with a different income, age, buying… | `skills/founder/founder-consumer/SKILL.md` |
| `founder-launch` | Your launch lead. Builds a dated, step-by-step launch plan: a cheap real-world test first (a waitlist, a pre-sale or a pop-up with a real price, so real buyers confirm… | `skills/founder/founder-launch/SKILL.md` |
| `founder-marketing` | Your marketing director. Turns the buyer panel and the competitor map into positioning, the channels the target customer actually uses, a 30-day launch campaign with… | `skills/founder/founder-marketing/SKILL.md` |
| `founder-offer` | Builds an offer too good to refuse. Lists every problem the buyer hits on the way to the result they want, turns each into a solution, trims to what is cheap to deliver… | `skills/founder/founder-offer/SKILL.md` |
| `founder-ops` | Your operations manager. Works out how the business actually runs on day one: suppliers and what they cost, who works when, the step-by-step routines for opening,… | `skills/founder/founder-ops/SKILL.md` |
| `founder-plan` | Your business planner. Compiles everything the other founder skills wrote (the board's verdict, the competitors, the buyer panel, pricing, the offer, the CFO's numbers,… | `skills/founder/founder-plan/SKILL.md` |
| `founder-pricing` | Finds the price buyers will actually pay. Reads the consumer panel's four price answers per buyer into a Van Westendorp price-sensitivity range (too cheap, a bargain,… | `skills/founder/founder-pricing/SKILL.md` |

### Marketing, SEO, growth, vendite (marketingskills)

| Skill | Quando usarla | File |
|---|---|---|
| `ab-testing` | When the user wants to plan, design, or implement an A/B test or experiment, or build a growth experimentation program. Also use when the user mentions "A/B test,"… | `skills/marketing/ab-testing/SKILL.md` |
| `ad-creative` | When the user wants to generate, iterate, or scale ad creative — headlines, descriptions, primary text, or full ad variations — for any paid advertising platform. Also… | `skills/marketing/ad-creative/SKILL.md` |
| `ads` | When the user wants help with paid advertising campaigns on Google Ads, Meta (Facebook/Instagram), LinkedIn, Twitter/X, or other ad platforms. Also use when the user… | `skills/marketing/ads/SKILL.md` |
| `ai-seo` | When the user wants to optimize content for AI search engines, get cited by LLMs, or appear in AI-generated answers. Also use when the user mentions 'AI SEO,' 'AEO,'… | `skills/marketing/ai-seo/SKILL.md` |
| `analytics` | When the user wants to set up, improve, or audit analytics tracking and measurement. Also use when the user mentions "set up tracking," "GA4," "Google Analytics,"… | `skills/marketing/analytics/SKILL.md` |
| `aso` | When the user wants to audit or optimize an App Store or Google Play listing. Also use when the user mentions 'ASO audit,' 'app store optimization,' 'optimize my app… | `skills/marketing/aso/SKILL.md` |
| `attribution` | When the user wants to figure out which marketing actually drives conversions and revenue, choose or interpret an attribution model, or reconcile conflicting numbers… | `skills/marketing/attribution/SKILL.md` |
| `churn-prevention` | When the user wants to reduce churn, build cancellation flows, set up save offers, recover failed payments, or implement retention strategies. Also use when the user… | `skills/marketing/churn-prevention/SKILL.md` |
| `co-marketing` | When the user wants to find co-marketing partners, plan joint campaigns, or brainstorm partnership opportunities. Use when the user says 'co-marketing,' 'partner… | `skills/marketing/co-marketing/SKILL.md` |
| `cold-email` | Write and run B2B cold outbound that gets replies, from cold emails and follow-ups to sending setup, LinkedIn, multichannel cadences, and reply handling. Use when the… | `skills/marketing/cold-email/SKILL.md` |
| `community-marketing` | Build and leverage online communities to drive product growth and brand loyalty. Use when the user wants to create a community strategy, grow a Discord or Slack… | `skills/marketing/community-marketing/SKILL.md` |
| `competitor-profiling` | When the user wants to research, profile, or analyze competitors from their URLs. Also use when the user mentions 'competitor profile,' 'competitor research,'… | `skills/marketing/competitor-profiling/SKILL.md` |
| `competitors` | When the user wants to create competitor comparison or alternative pages for SEO and buyer-facing use. Also use when the user mentions 'alternative page,' 'vs page,'… | `skills/marketing/competitors/SKILL.md` |
| `content-strategy` | When the user wants to plan a content strategy, decide what content to create, or figure out what topics to cover. Also use when the user mentions "content strategy,"… | `skills/marketing/content-strategy/SKILL.md` |
| `copy-editing` | When the user wants to edit, review, or improve existing marketing copy, or refresh outdated content. Also use when the user mentions 'edit this copy,' 'review my copy,'… | `skills/marketing/copy-editing/SKILL.md` |
| `copywriting` | When the user wants to write, rewrite, or improve marketing copy for any page, including homepage, landing pages, pricing pages, feature pages, about pages, or product… | `skills/marketing/copywriting/SKILL.md` |
| `cro` | When the user wants to optimize, improve, or increase conversions on any marketing page or form — including homepage, landing pages, pricing pages, feature pages, lead… | `skills/marketing/cro/SKILL.md` |
| `customer-research` | When the user wants to conduct, analyze, or synthesize customer research. Use when the user mentions "customer research," "ICP research," "talk to customers," "analyze… | `skills/marketing/customer-research/SKILL.md` |
| `directory-submissions` | When the user wants to submit their product to startup, SaaS, AI, agent, MCP, no-code, or review directories for backlinks, domain rating, and discovery. Also use when… | `skills/marketing/directory-submissions/SKILL.md` |
| `emails` | When the user wants to create or optimize an email sequence, drip campaign, automated email flow, or lifecycle email program. Also use when the user mentions "email… | `skills/marketing/emails/SKILL.md` |
| `events` | When the user wants to plan, run, sponsor, speak at, or get pipeline from events — webinars, conferences, trade shows, meetups, dinners, workshops, virtual summits, or… | `skills/marketing/events/SKILL.md` |
| `free-tools` | When the user wants to plan, evaluate, or build a free tool for marketing purposes — lead generation, SEO value, or brand awareness. Also use when the user mentions… | `skills/marketing/free-tools/SKILL.md` |
| `image` | When the user wants to create, generate, edit, or optimize images for marketing — blog heroes, social graphics, product mockups, profile banners, listing visuals, or… | `skills/marketing/image/SKILL.md` |
| `influencer-marketing` | When the user wants to run influencer, creator, or ambassador partnerships to promote their product — finding and vetting partners, structuring deals, briefing creators,… | `skills/marketing/influencer-marketing/SKILL.md` |
| `launch` | When the user wants to plan a product launch, feature announcement, or release strategy. Also use when the user mentions 'launch,' 'Product Hunt,' 'feature release,'… | `skills/marketing/launch/SKILL.md` |
| `lead-magnets` | When the user wants to create, plan, or optimize a lead magnet for email capture or lead generation. Also use when the user mentions "lead magnet," "gated content,"… | `skills/marketing/lead-magnets/SKILL.md` |
| `marketing-council` | When the user wants multiple expert perspectives on a marketing question — a simulated board of advisors staffed by legendary marketers (Seth Godin, David Ogilvy, Eugene… | `skills/marketing/marketing-council/SKILL.md` |
| `marketing-ideas` | When the user needs marketing ideas, inspiration, or strategies for their SaaS or software product. Also use when the user asks for 'marketing ideas,' 'growth ideas,'… | `skills/marketing/marketing-ideas/SKILL.md` |
| `marketing-loops` | When the user wants to set up a recurring, self-running marketing workflow — a repeatable loop an AI agent runs on a cadence (weekly, daily, on a trigger) rather than a… | `skills/marketing/marketing-loops/SKILL.md` |
| `marketing-plan` | When the user needs a comprehensive marketing plan for a client, a company they advise, or their own product. Also use when the user mentions "marketing plan," "growth… | `skills/marketing/marketing-plan/SKILL.md` |
| `marketing-psychology` | When the user wants to apply psychological principles, mental models, or behavioral science to marketing. Also use when the user mentions 'psychology,' 'mental models,'… | `skills/marketing/marketing-psychology/SKILL.md` |
| `offers` | When the user wants to design, construct, or improve an offer — the thing they actually sell — including value framing, bonus stacking, guarantee design,… | `skills/marketing/offers/SKILL.md` |
| `onboarding` | When the user wants to optimize post-signup onboarding, user activation, first-run experience, or time-to-value. Also use when the user mentions "onboarding flow,"… | `skills/marketing/onboarding/SKILL.md` |
| `paywalls` | When the user wants to create or optimize in-app paywalls, upgrade screens, upsell modals, or feature gates. Also use when the user mentions "paywall," "upgrade screen,"… | `skills/marketing/paywalls/SKILL.md` |
| `popups` | When the user wants to create or optimize popups, modals, overlays, slide-ins, or banners for conversion purposes. Also use when the user mentions "exit intent," "popup… | `skills/marketing/popups/SKILL.md` |
| `pricing` | When the user wants help with pricing decisions, packaging, or monetization strategy. Also use when the user mentions 'pricing,' 'pricing tiers,' 'freemium,' 'free… | `skills/marketing/pricing/SKILL.md` |
| `product-marketing` | When the user wants to create or update their product marketing context document. Also use when the user mentions 'product context,' 'marketing context,' 'set up… | `skills/marketing/product-marketing/SKILL.md` |
| `programmatic-seo` | When the user wants to create SEO-driven pages at scale using templates and data. Also use when the user mentions "programmatic SEO," "template pages," "pages at scale,"… | `skills/marketing/programmatic-seo/SKILL.md` |
| `prospecting` | When the user wants to find, qualify, and build a list of prospects to reach out to, across B2B SaaS, general B2B, or local small businesses. Also use when the user… | `skills/marketing/prospecting/SKILL.md` |
| `public-relations` | When the user wants help with public relations, earned media, press coverage, journalist outreach, or media strategy (not pull requests). Also use when the user mentions… | `skills/marketing/public-relations/SKILL.md` |
| `referrals` | When the user wants to create, optimize, or analyze a referral program, affiliate program, or word-of-mouth strategy. Also use when the user mentions 'referral,'… | `skills/marketing/referrals/SKILL.md` |
| `revops` | When the user wants help with revenue operations, lead lifecycle management, or marketing-to-sales handoff processes. Also use when the user mentions 'RevOps,' 'revenue… | `skills/marketing/revops/SKILL.md` |
| `sales-enablement` | When the user wants to create sales collateral, pitch decks, one-pagers, objection handling docs, or demo scripts. Also use when the user mentions 'sales deck,' 'pitch… | `skills/marketing/sales-enablement/SKILL.md` |
| `schema` | When the user wants to add, fix, or optimize schema markup and structured data on their site. Also use when the user mentions "schema markup," "structured data,"… | `skills/marketing/schema/SKILL.md` |
| `seo-audit` | When the user wants to audit, review, or diagnose SEO issues on their site. Also use when the user mentions "SEO audit," "technical SEO," "why am I not ranking," "SEO… | `skills/marketing/seo-audit/SKILL.md` |
| `signup` | When the user wants to optimize signup, registration, account creation, or trial activation flows. Also use when the user mentions "signup conversions," "registration… | `skills/marketing/signup/SKILL.md` |
| `site-architecture` | When the user wants to plan, map, or restructure their website's page hierarchy, navigation, URL structure, or internal linking. Also use when the user mentions… | `skills/marketing/site-architecture/SKILL.md` |
| `sms` | When the user wants to plan, build, or optimize SMS, MMS, or WhatsApp marketing — including welcome flows, abandoned cart texts, post-purchase, win-back, promotional… | `skills/marketing/sms/SKILL.md` |
| `social` | When the user wants help creating, scheduling, or optimizing social media content for LinkedIn, Twitter/X, Instagram, TikTok, or Facebook, or wants to do social… | `skills/marketing/social/SKILL.md` |
| `video` | When the user wants to create, generate, or produce video content using AI tools or programmatic frameworks. Also use when the user mentions 'video production,' 'AI… | `skills/marketing/video/SKILL.md` |

### Design UI/UX, brand, slide, design system (ui-ux-pro-max)

| Skill | Quando usarla | File |
|---|---|---|
| `banner-design` | Design banners for social media, ads, website heroes, creative assets, and print. Multiple art direction options with optional generated or supplied visuals. Actions:… | `skills/design/banner-design/SKILL.md` |
| `brand` | Brand voice, visual identity, messaging frameworks, asset management, brand consistency. Activate for branded content, tone of voice, marketing assets, brand compliance,… | `skills/design/brand/SKILL.md` |
| `design` | Comprehensive design skill: brand identity, design tokens, UI styling, logo generation (55 styles, Gemini, Atlas Cloud, or MuAPI AI), corporate identity program (50… | `skills/design/design/SKILL.md` |
| `design-system` | Token architecture, component specifications, and slide generation. Three-layer tokens (primitive→semantic→component), CSS variables, spacing/typography scales,… | `skills/design/design-system/SKILL.md` |
| `slides` | Create strategic HTML presentations with Chart.js, design tokens, responsive layouts, copywriting formulas, and contextual slide strategies. author: claudekit version:… | `skills/design/slides/SKILL.md` |
| `ui-styling` | Create beautiful, accessible user interfaces with shadcn/ui components (built on Radix UI + Tailwind), Tailwind CSS utility-first styling, and canvas-based visual… | `skills/design/ui-styling/SKILL.md` |
| `ui-ux-pro-max` | UI/UX design intelligence for web, mobile, and desktop. This skill should be used when designing, building, reviewing, or fixing interfaces, including pages, components,… | `skills/design/ui-ux-pro-max/SKILL.md` |

### Ingegneria: sicurezza e TDD (everything-claude-code)

| Skill | Quando usarla | File |
|---|---|---|
| `security-review` | Use this skill when adding authentication, handling user input, working with secrets, creating API endpoints, or implementing payment/sensitive features. Provides… | `skills/engineering/security-review/SKILL.md` |
| `tdd-workflow` | Use this skill when writing new features, fixing bugs, or refactoring code. Enforces test-driven development with 80%+ coverage including unit, integration, and E2E… | `skills/engineering/tdd-workflow/SKILL.md` |
| *(extra)* agenti, comandi, regole | planner, architect, code-reviewer, tdd-guide, build-error-resolver… | `skills/engineering/_agents/REFERENCES.md`, `_commands/REFERENCES.md`, `_rules/REFERENCES.md` |

### Scrittura: togliere il tono da AI (humanizer)

| Skill | Quando usarla | File |
|---|---|---|
| `humanizer` | Rewrite AI-sounding text so it reads like the writer without changing what it says. Use when editing or reviewing prose for AI tells: not-X-but-Y contrasts, one-line… | `skills/writing/humanizer/SKILL.md` |

## Note

- Le skill originali sono di terze parti (vedi `LICENSE` nelle rispettive cartelle) e restano in inglese; rispondi all'utente nella sua lingua.
- Alcuni script Python/Node nelle cartelle richiedono dipendenze: eseguili solo se utili e disponibili.
- Non inventare dati: se una skill richiede informazioni mancanti, chiedile all'utente.
